# Website Information Scraper – Task 1

## Overview
This project contains a lightweight Python-based website scraper created to extract observable website-level signals for early-stage pharma intelligence screening. The scraper focuses on transparency and reproducibility rather than exhaustive crawling.

## What the Script Does
- Checks commonly used website pages such as homepage, about, products, research, and contact pages
- Extracts visible text from accessible HTML pages
- Identifies probiotic-related keyword occurrences
- Flags whether probiotics are mentioned on the website
- Captures publicly available email addresses, if present
- Logs pages that are inaccessible or not found

## How to Run
1. Install the required dependencies:
2. Run the scraper:

## Output
The script produces structured output in JSON format, including:
- Pages successfully accessed or marked as not found
- Keyword frequency counts for probiotic-related terms
- A basic indicator of probiotic relevance
- Contact information, if publicly visible
- Metadata such as scrape timestamp

## Limitations
- Websites that rely heavily on JavaScript rendering may not expose content through static HTML requests.
- The scraper does not perform deep crawling, pagination, or form submissions.
- Scientific claims, regulatory compliance, and certifications are not validated.
- Absence of data on a website is recorded as "not found" and not inferred.

## Intended Use
This scraper is intended for preliminary screening of company websites using publicly available information and is not designed to replace detailed manual or regulatory review.