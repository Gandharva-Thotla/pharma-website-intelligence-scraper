!pip install requests beautifulsoup4

import requests
from bs4 import BeautifulSoup
from datetime import datetime
import re

COMMON_PAGES = [
    "",
    "/about",
    "/about-us",
    "/products",
    "/science",
    "/research",
    "/r-and-d",
    "/contact"
]

KEYWORDS = [
    "probiotic",
    "lactobacillus",
    "bifidobacterium",
    "gut health",
    "digestive",
    "live culture",
    "fermented"
]


def fetch_page(url):
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.text
    except Exception:
        return None
    return None


def extract_text(html):
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text(separator=" ", strip=True).lower()


def keyword_hits(text):
    hits = {}
    for kw in KEYWORDS:
        hits[kw] = text.count(kw)
    return hits


def scrape_company(base_url):
    result = {
        "identity": {
            "website": base_url
        },
        "pages_checked": {},
        "probiotic_signals": {},
        "contact_info": {},
        "metadata": {
            "scrape_time": datetime.now().isoformat()
        }
    }

    combined_text = ""

    for page in COMMON_PAGES:
        url = base_url.rstrip("/") + page
        html = fetch_page(url)

        if html:
            text = extract_text(html)
            combined_text += " " + text
            result["pages_checked"][page if page else "homepage"] = "found"
        else:
            result["pages_checked"][page if page else "homepage"] = "not found"

    result["probiotic_signals"]["keyword_frequency"] = keyword_hits(combined_text)
    result["probiotic_signals"]["mentions_probiotics"] = (
        result["probiotic_signals"]["keyword_frequency"].get("probiotic", 0) > 0
    )

    emails = set(
        re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", combined_text)
    )
    result["contact_info"]["emails"] = list(emails) if emails else "not found"

    return result


data = scrape_company("https://www.yakult.com")
data

import json

with open("yakult_scrape_output.json", "w") as f:
    json.dump(data, f, indent=4)

print("Saved output file")
